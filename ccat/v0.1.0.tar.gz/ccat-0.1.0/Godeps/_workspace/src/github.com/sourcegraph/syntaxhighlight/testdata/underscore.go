// +build ignore

package foo_bar

func foo() {
	for _, a := range foo {
	}
}
