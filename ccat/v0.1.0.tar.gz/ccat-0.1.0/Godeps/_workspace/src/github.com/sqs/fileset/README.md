# fileset

**fileset** is a Go package that mimics go/token's
[`FileSet`](https://sourcegraph.com/code.google.com/p/go/symbols/go/code.google.com/p/go/src/pkg/go/token/FileSet:type)
and exposes additional methods.

The code was copied from go/token.
