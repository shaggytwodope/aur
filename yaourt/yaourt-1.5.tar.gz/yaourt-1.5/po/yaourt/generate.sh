xgettext --from-code=utf-8 -L shell -j -kbuilduserinput -kuseragrees -kuserinput -kshow_targets -kaur_show_info -k_gettext -o toto ../../{,lib/}*.sh*
