package sourcegraph

type Checklist struct {
	Todo int // number of tasks to be done (unchecked)
	Done int // number of tasks that are done (checked)
}
