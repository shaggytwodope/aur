"""
Global configuration settings
"""

unicode = True