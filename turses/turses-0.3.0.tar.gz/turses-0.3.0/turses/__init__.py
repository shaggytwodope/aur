# -*- coding: utf-8 -*-

"""
turses
~~~~~~

A Twitter client for the console.
"""

__title__ = "turses"
__author__ = "Alejandro Gómez"
__copyright__ = "Copyright 2012-2013 turses contributors"
__license__ = "GPL3"
__version__ = (0, 3, 0)

version = "%s.%s.%s" % __version__
