from foo import bar

def f(self, a, b):
    print('hello!')
