rwvfs
=====

Package rwvfs augments vfs to support write operations.

* [rwvfs documentation](https://sourcegraph.com/sourcegraph/rwvfs)
* [golang.org/x/tools/godoc/vfs documentation](http://godoc.org/golang.org/x/tools/godoc/vfs)

[![Build Status](https://travis-ci.org/sourcegraph/rwvfs.png)](https://travis-ci.org/sourcegraph/rwvfs)


TODO
----

* Add corresponding implementations of `rwvfs.FileSystem` for mapfs and zipfs
