// Package ann defines types that represent source code annotations.
package ann
