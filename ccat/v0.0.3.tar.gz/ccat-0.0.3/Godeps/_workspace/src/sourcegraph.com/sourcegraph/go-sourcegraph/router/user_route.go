package router

var UserSpecPattern = `{UserSpec:[^@/]+}`
