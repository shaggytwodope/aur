
========================
Kitchen.iterutils Module
========================

.. automodule:: kitchen.iterutils

.. autofunction:: kitchen.iterutils.isiterable
.. autofunction:: kitchen.iterutils.iterate
