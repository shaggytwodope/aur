To use Comic Seer, you must have these prerequistes:
1) ZLib (included in most distros by default, this probably requires no work)
2) Qt4 (also included in most distros, but may require the Qt package)

Just unzip the contents of this zip file to a directory and run comicseer.

If you have a Debian-based distro (ie: Ubuntu, Debian), then the DEB package is recommended as opposed to the zip.
