package router

var PersonSpecPattern = `{PersonSpec:[^@/]+(?:@[^@/]+)?}`
