package main

import (
    "net/http"

    "github.com/odeke-em/log"
)

type netLogger struct {
}

func main() {
    logy := log.New()
}
