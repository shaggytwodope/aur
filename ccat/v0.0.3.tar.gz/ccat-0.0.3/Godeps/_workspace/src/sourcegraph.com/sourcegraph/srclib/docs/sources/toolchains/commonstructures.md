page_title: Common Data Structures

## Common Data Structures

### DefKey
The DefKey data structure is used to uniquely identify a definition, either locally, or in
another repository. This can be versioned, or unversioned.
[[.code "graph/def.pb.go" "DefKey"]]
