Nettop
------

This program was written as a top like program for network activity.  It is
licensed under a BSD type license, so you are free to do pretty much as you
like with this.

You will need to have libpcap and slang installed to run this program.  You
can obtain these packages at the following urls:

    ftp://space.mit.edu/pub/davis/slang/
    http://www.tcpdump.org/release/

Right now it isn't very portible at all, and doesn't use autoconf.  There are
also a lot more features that could be added, but i don't have the time or
insperation right now.  If you find this at all useful and have comments,
patches, or just want to let me know that you use it and would apprisiate
more features and stuff, i'd be glad to hear from you.

Scott Parish
<sRp@srparish.net>
