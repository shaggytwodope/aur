"this string\" continues to here"
