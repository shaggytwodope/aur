// foo is a cool function
function foo() {}

/* bar is a cool var */
var bar = 3;

A.prototype.foo = function() {
  this.noise || '<chirp>';
  return 'Hello from ' + this.name;
}
