## cli-spinner [![Build Status](https://travis-ci.org/odeke-em/cli-spinner.svg)](https://travis-ci.org/odeke-em/cli-spinner)

Spin until terminated


To see the quick demo via install
====

```shell
$ go get github.com/odeke-em/cli-spinner/cli-spinner
$ cli-spinner
```
