# Uploading to Sourcegraph

> Soon you will be able to upload builds generated locally into Sourcegraph's database.
