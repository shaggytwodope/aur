"""
Global configuration settings
"""

unicode = False
